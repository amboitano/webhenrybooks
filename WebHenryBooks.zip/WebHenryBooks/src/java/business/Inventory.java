
package business;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author acmor
 */
public class Inventory {
       public static List<Book> getBooks(int storeID) {
       // EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String qS = "SELECT * FROM bookinv p " +
                "LEFT JOIN booklist ON booklist.bookID = p.bookID" +
                " WHERE p.storeID = " + storeID;
        
//        TypedQuery<Book> q = em.createQuery(qS, Book.class);
//        q.setParameter("storeID", storeID);
        List<Book> books = new ArrayList<Book>();
            //Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPwd);
            try {
                
            
            ConnectionPool pool = ConnectionPool.getInstance(); //need to close?
            Connection conn = pool.getConnection();
            Statement s = conn.createStatement();
            //sql = "SELECT * FROM stores ORDER BY StoreName ";
            ResultSet r = s.executeQuery(qS);
            while (r.next()) {
                Book bk = new Book();
                bk.setAuthor(r.getString("author"));
                bk.setTitle(r.getString("title"));
                bk.setBookID(r.getString("bookID"));
                bk.setStoreID(Integer.toString(storeID));
                bk.setOnHand(r.getInt("OnHand"));
                bk.setPrice(r.getDouble("price"));
                
                //st.setStoreaddr(r.rgetString("StoreAddr"));
                //st.setStoreemp(r.getInt("StoreEmp"));
                books.add(bk);
            }
            } catch (Exception e){
                
            }
            return books;
//        try {
//            p = q.getResultList();
//            if (p==null || p.isEmpty()) {
//            p = null;
//        }
//        } catch (NoResultException e) {
//            p = null;
//        } finally {
//            em.close();
//        }
//        return p;}
}
}